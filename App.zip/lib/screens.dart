import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'api.dart';
import 'config.dart';
import 'state.dart';

extension Tr on BuildContext {
  String tr(String k) => watch<AppState>().t(k);
}

const _live = {'1H', 'HT', '2H', 'ET', 'BT', 'P', 'LIVE', 'INT', 'SUSP'};
const _done = {'FT', 'AET', 'PEN'};
String _ymd(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
int get _season { final n = DateTime.now(); return n.month >= 7 ? n.year : n.year - 1; }
void _push(BuildContext c, Widget w) => Navigator.of(c).push(MaterialPageRoute(builder: (_) => w));
Widget _logo(String? u, {double s = 28}) => u == null
    ? Icon(Icons.shield_outlined, size: s * .8)
    : Image.network(u, width: s, height: s, errorBuilder: (_, __, ___) => Icon(Icons.shield_outlined, size: s * .8));

// ───────── Generic async view with loading / empty / error / refresh ─────────
class AsyncView extends StatefulWidget {
  final Future<List> Function() load;
  final Widget Function(BuildContext, List) builder;
  final Duration? refresh;
  final String emptyKey;
  const AsyncView({super.key, required this.load, required this.builder, this.refresh, this.emptyKey = 'no_data'});
  @override
  State<AsyncView> createState() => _AsyncViewState();
}

class _AsyncViewState extends State<AsyncView> {
  late Future<List> f;
  Timer? t;
  @override
  void initState() {
    super.initState();
    f = widget.load();
    if (widget.refresh != null) {
      t = Timer.periodic(widget.refresh!, (_) { if (mounted) setState(() => f = widget.load()); });
    }
  }
  @override
  void dispose() { t?.cancel(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List>(
      future: f,
      builder: (c, s) {
        if (s.hasData) {
          final d = s.data!;
          if (d.isEmpty) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(c.tr(widget.emptyKey), textAlign: TextAlign.center)));
          return RefreshIndicator(
            onRefresh: () async { setState(() => f = widget.load()); try { await f; } catch (_) {} },
            child: widget.builder(c, d),
          );
        }
        if (s.hasError) {
          final e = s.error;
          final msg = e is ApiException && e.message == 'no_key' ? c.tr('no_key') : c.tr('error');
          return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.cloud_off, size: 48),
            const SizedBox(height: 12),
            Text(msg, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            FilledButton(onPressed: () => setState(() => f = widget.load()), child: Text(c.tr('retry'))),
          ])));
        }
        return const Center(child: CircularProgressIndicator());
      },
    );
  }
}

// ───────── Shell with bottom navigation ─────────
class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext c) {
    const pages = [HomeScreen(), MatchesScreen(), LeaguesScreen(), NewsScreen(), SettingsScreen()];
    return Scaffold(
      body: pages[i],
      bottomNavigationBar: NavigationBar(
        selectedIndex: i,
        onDestinationSelected: (v) => setState(() => i = v),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: c.tr('home')),
          NavigationDestination(icon: const Icon(Icons.sports_soccer_outlined), selectedIcon: const Icon(Icons.sports_soccer), label: c.tr('matches')),
          NavigationDestination(icon: const Icon(Icons.emoji_events_outlined), selectedIcon: const Icon(Icons.emoji_events), label: c.tr('leagues')),
          NavigationDestination(icon: const Icon(Icons.newspaper_outlined), selectedIcon: const Icon(Icons.newspaper), label: c.tr('news')),
          NavigationDestination(icon: const Icon(Icons.settings_outlined), selectedIcon: const Icon(Icons.settings), label: c.tr('settings')),
        ],
      ),
    );
  }
}

// ───────── Fixtures list & card ─────────
Widget fixtureList(BuildContext c, List d) {
  final groups = <String, List>{};
  for (final m in d) { groups.putIfAbsent('${m['league']['id']}', () => []).add(m); }
  return ListView(
    physics: const AlwaysScrollableScrollPhysics(),
    padding: const EdgeInsets.all(8),
    children: [
      for (final g in groups.values) ...[
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 12, 8, 4),
          child: Row(children: [
            _logo(g.first['league']['logo'], s: 20),
            const SizedBox(width: 8),
            Expanded(child: Text('${g.first['league']['name']} · ${g.first['league']['country'] ?? ''}', style: Theme.of(c).textTheme.titleSmall, overflow: TextOverflow.ellipsis)),
          ]),
        ),
        for (final m in g) FixtureCard(m: m),
      ],
    ],
  );
}

class FixtureCard extends StatelessWidget {
  final Map m;
  const FixtureCard({super.key, required this.m});
  @override
  Widget build(BuildContext c) {
    final st = m['fixture']['status']['short'] as String;
    final h = m['teams']['home'], a = m['teams']['away'], g = m['goals'];
    final live = _live.contains(st), done = _done.contains(st);
    final kick = DateTime.tryParse('${m['fixture']['date']}')?.toLocal();
    final time = kick == null ? '' : '${kick.hour.toString().padLeft(2, '0')}:${kick.minute.toString().padLeft(2, '0')}';
    final scheme = Theme.of(c).colorScheme;
    Widget team(Map t) => Expanded(child: Column(children: [
      _logo(t['logo'], s: 36),
      const SizedBox(height: 4),
      Text('${t['name']}', maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
    ]));
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => _push(c, MatchScreen(m: m)),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            team(h),
            SizedBox(width: 84, child: Column(children: [
              Text(live || done ? '${g['home'] ?? 0} - ${g['away'] ?? 0}' : time,
                  style: Theme.of(c).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 4),
              Text(live ? (st == 'HT' ? 'HT' : "${m['fixture']['status']['elapsed'] ?? ''}'") : (done ? st : '${m['fixture']['status']['short']}'),
                  style: TextStyle(color: live ? Colors.red : scheme.outline, fontWeight: FontWeight.w600, fontSize: 12)),
            ])),
            team(a),
          ]),
        ),
      ),
    );
  }
}

// ───────── Home ─────────
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext c) {
    final s = c.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(c.tr('home')), actions: [
        IconButton(icon: const Icon(Icons.search), onPressed: () => _push(c, const SearchScreen())),
      ]),
      body: AsyncView(
        key: ValueKey('home${s.favs.length}'),
        refresh: AppConfig.liveRefresh * 2,
        emptyKey: 'no_data',
        load: () async {
          final all = await Api.i.get('/fixtures', {'date': _ymd(DateTime.now())}, ttl: const Duration(seconds: 60));
          bool keep(m) {
            final lid = m['league']['id'], h = m['teams']['home']['id'], a = m['teams']['away']['id'];
            if (s.favs.isEmpty) return AppConfig.topLeagues.containsKey(lid);
            return s.favs.any((x) => (x['type'] == 'league' && x['id'] == lid) || (x['type'] == 'team' && (x['id'] == h || x['id'] == a)));
          }
          final r = all.where(keep).toList();
          int lv(m) => _live.contains(m['fixture']['status']['short']) ? 0 : 1;
          r.sort((a, b) => lv(a) - lv(b));
          return r;
        },
        builder: fixtureList,
      ),
    );
  }
}

// ───────── Matches ─────────
class MatchesScreen extends StatelessWidget {
  const MatchesScreen({super.key});
  Widget day(DateTime? d) => AsyncView(
        refresh: d == null ? AppConfig.liveRefresh : null,
        load: () => d == null
            ? Api.i.get('/fixtures', {'live': 'all'}, ttl: const Duration(seconds: 20))
            : Api.i.get('/fixtures', {'date': _ymd(d)}, ttl: const Duration(minutes: 3)),
        builder: fixtureList,
      );
  @override
  Widget build(BuildContext c) {
    final n = DateTime.now();
    return DefaultTabController(
      length: 4,
      initialIndex: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text(c.tr('matches')),
          bottom: TabBar(tabs: [Tab(text: c.tr('live')), Tab(text: c.tr('yesterday')), Tab(text: c.tr('today')), Tab(text: c.tr('tomorrow'))]),
        ),
        body: TabBarView(children: [
          day(null),
          day(n.subtract(const Duration(days: 1))),
          day(n),
          day(n.add(const Duration(days: 1))),
        ]),
      ),
    );
  }
}

// ───────── Leagues ─────────
class LeaguesScreen extends StatelessWidget {
  const LeaguesScreen({super.key});
  @override
  Widget build(BuildContext c) {
    final s = c.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(c.tr('leagues')), actions: [
        IconButton(icon: const Icon(Icons.search), onPressed: () => _push(c, const SearchScreen())),
      ]),
      body: ListView(children: [
        for (final e in AppConfig.topLeagues.entries)
          ListTile(
            leading: _logo('${AppConfig.mediaUrl}/leagues/${e.key}.png'),
            title: Text(e.value),
            trailing: IconButton(
              icon: Icon(s.isFav('league', e.key) ? Icons.star : Icons.star_border),
              onPressed: () => s.toggleFav('league', e.key, e.value, '${AppConfig.mediaUrl}/leagues/${e.key}.png'),
            ),
            onTap: () => _push(c, LeagueScreen(id: e.key, name: e.value, logo: '${AppConfig.mediaUrl}/leagues/${e.key}.png')),
          ),
      ]),
    );
  }
}

class LeagueScreen extends StatelessWidget {
  final int id;
  final String name;
  final String? logo;
  const LeagueScreen({super.key, required this.id, required this.name, this.logo});
  @override
  Widget build(BuildContext c) {
    final s = c.watch<AppState>();
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text(name),
          actions: [IconButton(icon: Icon(s.isFav('league', id) ? Icons.star : Icons.star_border), onPressed: () => s.toggleFav('league', id, name, logo))],
          bottom: TabBar(tabs: [Tab(text: c.tr('standings')), Tab(text: c.tr('fixtures')), Tab(text: c.tr('results'))]),
        ),
        body: TabBarView(children: [
          AsyncView(
            load: () async {
              final r = await Api.i.get('/standings', {'league': '$id', 'season': '$_season'}, ttl: const Duration(minutes: 30));
              if (r.isEmpty) return [];
              return (r[0]['league']['standings'] as List)[0] as List;
            },
            builder: (c, d) => ListView(physics: const AlwaysScrollableScrollPhysics(), children: [
              for (final r in d)
                ListTile(
                  dense: true,
                  leading: Row(mainAxisSize: MainAxisSize.min, children: [SizedBox(width: 24, child: Text('${r['rank']}')), _logo(r['team']['logo'], s: 24)]),
                  title: Text('${r['team']['name']}'),
                  subtitle: Text('P ${r['all']['played']}  GD ${r['goalsDiff']}'),
                  trailing: Text('${r['points']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  onTap: () => _push(c, TeamScreen(id: r['team']['id'], name: '${r['team']['name']}', logo: r['team']['logo'])),
                ),
            ]),
          ),
          AsyncView(load: () => Api.i.get('/fixtures', {'league': '$id', 'season': '$_season', 'next': '20'}), builder: fixtureList),
          AsyncView(load: () => Api.i.get('/fixtures', {'league': '$id', 'season': '$_season', 'last': '20'}), builder: fixtureList),
        ]),
      ),
    );
  }
}

// ───────── Team ─────────
class TeamScreen extends StatelessWidget {
  final int id;
  final String name;
  final String? logo;
  const TeamScreen({super.key, required this.id, required this.name, this.logo});
  @override
  Widget build(BuildContext c) {
    final s = c.watch<AppState>();
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Row(children: [_logo(logo, s: 28), const SizedBox(width: 8), Flexible(child: Text(name, overflow: TextOverflow.ellipsis))]),
          actions: [IconButton(icon: Icon(s.isFav('team', id) ? Icons.star : Icons.star_border), onPressed: () => s.toggleFav('team', id, name, logo))],
          bottom: TabBar(tabs: [Tab(text: c.tr('matches_tab')), Tab(text: c.tr('squad'))]),
        ),
        body: TabBarView(children: [
          AsyncView(
            load: () async {
              final a = await Api.i.get('/fixtures', {'team': '$id', 'next': '10'});
              final b = await Api.i.get('/fixtures', {'team': '$id', 'last': '10'});
              return [...a, ...b.reversed];
            },
            builder: fixtureList,
          ),
          AsyncView(
            load: () async {
              final r = await Api.i.get('/players/squads', {'team': '$id'}, ttl: const Duration(hours: 12));
              return r.isEmpty ? [] : r[0]['players'] as List;
            },
            builder: (c, d) => ListView(physics: const AlwaysScrollableScrollPhysics(), children: [
              for (final p in d)
                ListTile(
                  leading: CircleAvatar(backgroundImage: p['photo'] != null ? NetworkImage('${p['photo']}') : null, child: p['photo'] == null ? const Icon(Icons.person) : null),
                  title: Text('${p['name']}'),
                  subtitle: Text('${p['position'] ?? ''} · ${p['age'] ?? ''}'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text('${p['number'] ?? ''}'),
                    IconButton(
                      icon: Icon(s.isFav('player', p['id']) ? Icons.star : Icons.star_border),
                      onPressed: () => s.toggleFav('player', p['id'], '${p['name']}', p['photo']),
                    ),
                  ]),
                ),
            ]),
          ),
        ]),
      ),
    );
  }
}

// ───────── Match details ─────────
class MatchScreen extends StatelessWidget {
  final Map m;
  const MatchScreen({super.key, required this.m});
  @override
  Widget build(BuildContext c) {
    final fx = m['fixture'];
    final id = fx['id'] as int;
    final st = fx['status']['short'] as String;
    final live = _live.contains(st), done = _done.contains(st);
    final h = m['teams']['home'], a = m['teams']['away'], g = m['goals'];
    final tabs = [c.tr('events'), c.tr('lineups'), c.tr('stats'), if (done) c.tr('highlights')];
    Widget team(Map t) => Expanded(child: InkWell(
          onTap: () => _push(c, TeamScreen(id: t['id'], name: '${t['name']}', logo: t['logo'])),
          child: Column(children: [_logo(t['logo'], s: 48), const SizedBox(height: 6), Text('${t['name']}', textAlign: TextAlign.center)]),
        ));
    return DefaultTabController(
      length: tabs.length,
      child: Scaffold(
        appBar: AppBar(title: Text('${m['league']['name']}')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              team(h),
              Column(children: [
                Text(live || done ? '${g['home'] ?? 0} - ${g['away'] ?? 0}' : '—', style: Theme.of(c).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.bold)),
                Text(live ? "${fx['status']['elapsed'] ?? ''}'" : '${fx['status']['long']}', style: TextStyle(color: live ? Colors.red : null)),
              ]),
              team(a),
            ]),
          ),
          TabBar(isScrollable: true, tabs: [for (final t in tabs) Tab(text: t)]),
          Expanded(
            child: TabBarView(children: [
              AsyncView(
                refresh: live ? AppConfig.liveRefresh : null,
                load: () => Api.i.get('/fixtures/events', {'fixture': '$id'}, ttl: Duration(seconds: live ? 20 : 3600)),
                builder: (c, d) => ListView(physics: const AlwaysScrollableScrollPhysics(), children: [
                  for (final e in d)
                    ListTile(
                      leading: SizedBox(width: 40, child: Text("${e['time']['elapsed']}'", style: const TextStyle(fontWeight: FontWeight.bold))),
                      title: Text('${e['player']['name'] ?? ''}'),
                      subtitle: Text('${e['type']} · ${e['detail']}${e['assist']?['name'] != null ? ' (${e['assist']['name']})' : ''}'),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [_icon(e), const SizedBox(width: 8), _logo(e['team']['logo'], s: 22)]),
                    ),
                ]),
              ),
              AsyncView(
                load: () => Api.i.get('/fixtures/lineups', {'fixture': '$id'}, ttl: const Duration(minutes: 10)),
                builder: (c, d) => ListView(physics: const AlwaysScrollableScrollPhysics(), children: [
                  for (final t in d) ...[
                    ListTile(leading: _logo(t['team']['logo']), title: Text('${t['team']['name']}  ${t['formation'] ?? ''}'), subtitle: Text('${t['coach']?['name'] ?? ''}')),
                    for (final p in t['startXI']) ListTile(dense: true, leading: Text('${p['player']['number'] ?? ''}'), title: Text('${p['player']['name']}'), subtitle: Text('${p['player']['pos'] ?? ''}')),
                    for (final p in t['substitutes']) ListTile(dense: true, leading: Text('${p['player']['number'] ?? ''}'), title: Text('${p['player']['name']}', style: const TextStyle(fontStyle: FontStyle.italic))),
                    const Divider(),
                  ],
                ]),
              ),
              AsyncView(
                refresh: live ? AppConfig.liveRefresh : null,
                load: () => Api.i.get('/fixtures/statistics', {'fixture': '$id'}, ttl: Duration(seconds: live ? 20 : 3600)),
                builder: (c, d) {
                  final hs = d[0]['statistics'] as List;
                  final as = d.length > 1 ? d[1]['statistics'] as List : [];
                  return ListView(physics: const AlwaysScrollableScrollPhysics(), children: [
                    for (int i = 0; i < hs.length; i++)
                      ListTile(
                        dense: true,
                        leading: SizedBox(width: 48, child: Text('${hs[i]['value'] ?? 0}')),
                        title: Center(child: Text('${hs[i]['type']}')),
                        trailing: SizedBox(width: 48, child: Text('${i < as.length ? (as[i]['value'] ?? 0) : '-'}', textAlign: TextAlign.end)),
                      ),
                  ]);
                },
              ),
              if (done)
                AsyncView(
                  emptyKey: 'no_highlights',
                  load: () => Api.i.highlights(id, '${h['name']}', '${a['name']}'),
                  builder: (c, d) => HighlightPlayer(items: d),
                ),
            ]),
          ),
        ]),
      ),
    );
  }

  Widget _icon(Map e) {
    final t = '${e['type']}', d = '${e['detail']}';
    if (t == 'Goal') return const Icon(Icons.sports_soccer, size: 20);
    if (t == 'Card') return Icon(Icons.style, size: 20, color: d.contains('Red') ? Colors.red : Colors.amber);
    if (t == 'subst') return const Icon(Icons.swap_horiz, size: 20);
    return const Icon(Icons.flag_outlined, size: 20);
  }
}

/// Embedded in-app player: only plays official embeds/links supplied by the configured source.
class HighlightPlayer extends StatefulWidget {
  final List items;
  const HighlightPlayer({super.key, required this.items});
  @override
  State<HighlightPlayer> createState() => _HighlightPlayerState();
}

class _HighlightPlayerState extends State<HighlightPlayer> {
  final ctl = WebViewController()..setJavaScriptMode(JavaScriptMode.unrestricted);
  int sel = 0;
  @override
  void initState() { super.initState(); _play(0); }
  void _play(int i) {
    final it = widget.items[i] as Map;
    final e = it['embed'] ?? it['embedHtml'];
    if (e is String && e.isNotEmpty) {
      ctl.loadHtmlString('<html><body style="margin:0;background:#000">$e</body></html>');
    } else if (it['url'] != null) {
      ctl.loadRequest(Uri.parse('${it['url']}'));
    }
    setState(() => sel = i);
  }
  @override
  Widget build(BuildContext c) => Column(children: [
        AspectRatio(aspectRatio: 16 / 9, child: WebViewWidget(controller: ctl)),
        Expanded(child: ListView(children: [
          for (int i = 0; i < widget.items.length; i++)
            ListTile(selected: i == sel, leading: const Icon(Icons.play_circle_outline), title: Text('${widget.items[i]['title'] ?? ''}'), onTap: () => _play(i)),
        ])),
      ]);
}

// ───────── News (optional RSS) ─────────
class NewsScreen extends StatelessWidget {
  const NewsScreen({super.key});
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: Text(c.tr('news'))),
        body: AsyncView(
          emptyKey: 'no_news',
          load: Api.i.news,
          builder: (c, d) => ListView(physics: const AlwaysScrollableScrollPhysics(), children: [
            for (final n in d)
              ListTile(
                leading: const Icon(Icons.article_outlined),
                title: Text('${n['title']}'),
                onTap: () => _push(c, WebPage(url: '${n['link']}')),
              ),
          ]),
        ),
      );
}

class WebPage extends StatelessWidget {
  final String url;
  const WebPage({super.key, required this.url});
  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(),
        body: WebViewWidget(controller: WebViewController()..setJavaScriptMode(JavaScriptMode.unrestricted)..loadRequest(Uri.parse(url))),
      );
}

// ───────── Search ─────────
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});
  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List teams = [], leagues = [];
  bool busy = false;
  String? err;
  Future<void> run(String q) async {
    if (q.trim().length < 3) return;
    setState(() { busy = true; err = null; });
    try {
      final r = await Future.wait([
        Api.i.get('/teams', {'search': q.trim()}, ttl: const Duration(hours: 6)),
        Api.i.get('/leagues', {'search': q.trim()}, ttl: const Duration(hours: 6)),
      ]);
      teams = r[0]; leagues = r[1];
    } catch (e) {
      err = e is ApiException && e.message == 'no_key' ? 'no_key' : 'error';
    }
    if (mounted) setState(() => busy = false);
  }
  @override
  Widget build(BuildContext c) {
    return Scaffold(
      appBar: AppBar(title: TextField(autofocus: true, textInputAction: TextInputAction.search, onSubmitted: run, decoration: InputDecoration(hintText: c.tr('hint_search'), border: InputBorder.none))),
      body: busy
          ? const Center(child: CircularProgressIndicator())
          : err != null
              ? Center(child: Text(c.tr(err!)))
              : (teams.isEmpty && leagues.isEmpty)
                  ? Center(child: Text(c.tr('no_data')))
                  : ListView(children: [
                      for (final t in teams)
                        ListTile(leading: _logo(t['team']['logo']), title: Text('${t['team']['name']}'), subtitle: Text('${t['team']['country'] ?? ''}'),
                            onTap: () => _push(c, TeamScreen(id: t['team']['id'], name: '${t['team']['name']}', logo: t['team']['logo']))),
                      for (final l in leagues)
                        ListTile(leading: _logo(l['league']['logo']), title: Text('${l['league']['name']}'), subtitle: Text('${l['country']?['name'] ?? ''}'),
                            onTap: () => _push(c, LeagueScreen(id: l['league']['id'], name: '${l['league']['name']}', logo: l['league']['logo']))),
                    ]),
    );
  }
}

// ───────── Settings & favorites ─────────
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});
  @override
  Widget build(BuildContext c) {
    final s = c.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(c.tr('settings'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(c.tr('theme'), style: Theme.of(c).textTheme.titleMedium),
        const SizedBox(height: 8),
        SegmentedButton<ThemeMode>(
          segments: [
            ButtonSegment(value: ThemeMode.system, label: Text(c.tr('system'))),
            ButtonSegment(value: ThemeMode.light, label: Text(c.tr('light'))),
            ButtonSegment(value: ThemeMode.dark, label: Text(c.tr('dark'))),
          ],
          selected: {s.themeMode},
          onSelectionChanged: (v) => s.setTheme(v.first),
        ),
        const SizedBox(height: 16),
        Text(c.tr('language'), style: Theme.of(c).textTheme.titleMedium),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          segments: const [ButtonSegment(value: 'en', label: Text('English')), ButtonSegment(value: 'ar', label: Text('العربية'))],
          selected: {s.locale.languageCode},
          onSelectionChanged: (v) => s.setLang(v.first),
        ),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: Text(c.tr('notifications')), subtitle: Text(c.tr('noti_note')), value: s.notifications, onChanged: s.setNoti),
        const Divider(),
        Text(c.tr('favorites'), style: Theme.of(c).textTheme.titleMedium),
        if (s.favs.isEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 16), child: Text(c.tr('no_favs'))),
        for (final f in s.favs)
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: _logo(f['logo'] as String?),
            title: Text('${f['name']}'),
            subtitle: Text('${f['type']}'),
            trailing: IconButton(icon: const Icon(Icons.star), onPressed: () => s.toggleFav(f['type'], f['id'], f['name'], f['logo'])),
            onTap: () {
              if (f['type'] == 'team') _push(c, TeamScreen(id: f['id'], name: f['name'], logo: f['logo']));
              if (f['type'] == 'league') _push(c, LeagueScreen(id: f['id'], name: f['name'], logo: f['logo']));
            },
          ),
      ]),
    );
  }
}
