/// Central API configuration. Change provider here.
class AppConfig {
  // Supply with: --dart-define=API_KEY=xxxx  (or GitHub secret API_KEY)
  static const apiKey = String.fromEnvironment('API_KEY');
  static const baseUrl = 'https://v3.football.api-sports.io';
  static const keyHeader = 'x-apisports-key';
  static const mediaUrl = 'https://media.api-sports.io/football';

  /// Optional RSS feed URL for the News tab (empty = disabled).
  static const newsFeedUrl = '';

  /// Optional highlights endpoint (empty = disabled). Placeholders: {id} {home} {away}.
  /// Must return a JSON list (or {"response": [...]}) of items with
  /// "title" and either "embed" (HTML iframe) or "url" (official video page).
  static const highlightsUrlTemplate = '';

  static const liveRefresh = Duration(seconds: 30);
  static const topLeagues = <int, String>{
    39: 'Premier League', 140: 'La Liga', 135: 'Serie A', 78: 'Bundesliga',
    61: 'Ligue 1', 2: 'UEFA Champions League', 3: 'UEFA Europa League',
    307: 'Saudi Pro League', 233: 'Egyptian Premier League', 200: 'Botola Pro',
  };
}
