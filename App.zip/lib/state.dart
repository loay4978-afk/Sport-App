import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _s = <String, Map<String, String>>{
  'en': {
    'home': 'Home', 'matches': 'Matches', 'leagues': 'Leagues', 'news': 'News', 'settings': 'Settings',
    'live': 'Live', 'yesterday': 'Yesterday', 'today': 'Today', 'tomorrow': 'Tomorrow',
    'search': 'Search', 'hint_search': 'Teams or leagues (min 3 letters)', 'favorites': 'Favorites',
    'standings': 'Standings', 'fixtures': 'Fixtures', 'results': 'Results', 'events': 'Events',
    'lineups': 'Lineups', 'stats': 'Statistics', 'highlights': 'Highlights', 'squad': 'Squad',
    'no_data': 'Nothing to show right now.', 'retry': 'Retry', 'error': 'Could not load data. Check your connection.',
    'no_key': 'API key missing. Build with --dart-define=API_KEY=your_key (see README).',
    'no_highlights': 'No highlights are currently available for this match.',
    'no_news': 'News is not provided by the sports API. Set a feed URL in lib/config.dart to enable it.',
    'theme': 'Theme', 'language': 'Language', 'notifications': 'Match notifications',
    'noti_note': 'Preference saved. Push delivery is not enabled in this version.',
    'light': 'Light', 'dark': 'Dark', 'system': 'System', 'no_favs': 'No favorites yet. Tap the star on a team or league.',
    'teams': 'Teams', 'matches_tab': 'Matches',
  },
  'ar': {
    'home': 'الرئيسية', 'matches': 'المباريات', 'leagues': 'الدوريات', 'news': 'الأخبار', 'settings': 'الإعدادات',
    'live': 'مباشر', 'yesterday': 'أمس', 'today': 'اليوم', 'tomorrow': 'غداً',
    'search': 'بحث', 'hint_search': 'فرق أو دوريات (3 أحرف على الأقل)', 'favorites': 'المفضلة',
    'standings': 'الترتيب', 'fixtures': 'المباريات القادمة', 'results': 'النتائج', 'events': 'الأحداث',
    'lineups': 'التشكيلات', 'stats': 'الإحصائيات', 'highlights': 'الملخصات', 'squad': 'اللاعبون',
    'no_data': 'لا توجد بيانات حالياً.', 'retry': 'إعادة المحاولة', 'error': 'تعذر تحميل البيانات. تحقق من الاتصال.',
    'no_key': 'مفتاح API غير موجود. شغّل مع --dart-define=API_KEY=مفتاحك (راجع README).',
    'no_highlights': 'لا توجد ملخصات متاحة لهذه المباراة حالياً.',
    'no_news': 'الأخبار غير متوفرة في واجهة بيانات الرياضة. أضف رابط خلاصة في lib/config.dart لتفعيلها.',
    'theme': 'المظهر', 'language': 'اللغة', 'notifications': 'إشعارات المباريات',
    'noti_note': 'تم حفظ التفضيل. إرسال الإشعارات غير مفعّل في هذا الإصدار.',
    'light': 'فاتح', 'dark': 'داكن', 'system': 'النظام', 'no_favs': 'لا توجد مفضلة بعد. اضغط النجمة على فريق أو دوري.',
    'teams': 'الفرق', 'matches_tab': 'المباريات',
  },
};

class AppState extends ChangeNotifier {
  late SharedPreferences _p;
  ThemeMode themeMode = ThemeMode.system;
  Locale locale = const Locale('en');
  bool notifications = true;
  List<Map<String, dynamic>> favs = [];

  Future<void> load() async {
    _p = await SharedPreferences.getInstance();
    themeMode = ThemeMode.values[_p.getInt('theme') ?? 0];
    locale = Locale(_p.getString('lang') ?? 'en');
    notifications = _p.getBool('noti') ?? true;
    final f = _p.getString('favs');
    if (f != null) favs = (jsonDecode(f) as List).map((e) => Map<String, dynamic>.from(e)).toList();
  }

  String t(String k) => _s[locale.languageCode]?[k] ?? _s['en']![k] ?? k;

  bool isFav(String type, int id) => favs.any((f) => f['type'] == type && f['id'] == id);

  void toggleFav(String type, int id, String name, String? logo) {
    if (isFav(type, id)) {
      favs.removeWhere((f) => f['type'] == type && f['id'] == id);
    } else {
      favs.add({'type': type, 'id': id, 'name': name, 'logo': logo});
    }
    _p.setString('favs', jsonEncode(favs));
    notifyListeners();
  }

  void setTheme(ThemeMode m) { themeMode = m; _p.setInt('theme', m.index); notifyListeners(); }
  void setLang(String l) { locale = Locale(l); _p.setString('lang', l); notifyListeners(); }
  void setNoti(bool v) { notifications = v; _p.setBool('noti', v); notifyListeners(); }
}
