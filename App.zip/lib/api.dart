import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class Api {
  static final Api i = Api._();
  Api._();
  SharedPreferences? _p;

  /// GET with TTL cache; falls back to stale cache when offline.
  Future<List> get(String path, Map<String, String> q,
      {Duration ttl = const Duration(minutes: 5)}) async {
    _p ??= await SharedPreferences.getInstance();
    final uri = Uri.parse(AppConfig.baseUrl + path).replace(queryParameters: q);
    final key = 'c:$uri';
    final cached = _p!.getString(key);
    if (cached != null) {
      final m = jsonDecode(cached);
      if (DateTime.now().millisecondsSinceEpoch - (m['t'] as int) < ttl.inMilliseconds) {
        return m['d'] as List;
      }
    }
    if (AppConfig.apiKey.isEmpty) {
      if (cached != null) return jsonDecode(cached)['d'] as List;
      throw ApiException('no_key');
    }
    try {
      final r = await http
          .get(uri, headers: {AppConfig.keyHeader: AppConfig.apiKey})
          .timeout(const Duration(seconds: 15));
      if (r.statusCode != 200) throw ApiException('http ${r.statusCode}');
      final j = jsonDecode(r.body);
      final errs = j['errors'];
      if (errs is Map && errs.isNotEmpty) throw ApiException(errs.values.first.toString());
      final d = j['response'] as List;
      await _p!.setString(key, jsonEncode({'t': DateTime.now().millisecondsSinceEpoch, 'd': d}));
      return d;
    } catch (e) {
      if (cached != null) return jsonDecode(cached)['d'] as List;
      if (e is ApiException) rethrow;
      throw ApiException('network');
    }
  }

  Future<List> highlights(int id, String home, String away) async {
    if (AppConfig.highlightsUrlTemplate.isEmpty) return [];
    final url = AppConfig.highlightsUrlTemplate
        .replaceAll('{id}', '$id')
        .replaceAll('{home}', Uri.encodeComponent(home))
        .replaceAll('{away}', Uri.encodeComponent(away));
    final r = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) throw ApiException('http ${r.statusCode}');
    final j = jsonDecode(r.body);
    return j is List ? j : ((j['response'] as List?) ?? []);
  }

  Future<List> news() async {
    if (AppConfig.newsFeedUrl.isEmpty) return [];
    final r = await http.get(Uri.parse(AppConfig.newsFeedUrl)).timeout(const Duration(seconds: 15));
    if (r.statusCode != 200) throw ApiException('http ${r.statusCode}');
    final items = RegExp(r'<item>(.*?)</item>', dotAll: true).allMatches(r.body);
    return items.map((m) {
      final s = m.group(1)!;
      final t = RegExp(r'<title>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</title>', dotAll: true).firstMatch(s)?.group(1) ?? '';
      final l = RegExp(r'<link>(.*?)</link>', dotAll: true).firstMatch(s)?.group(1)?.trim() ?? '';
      return {'title': t.trim(), 'link': l};
    }).toList();
  }
}
