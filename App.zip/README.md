# Pitchly
Flutter football app. Data: API-Football (api-sports.io). No backend, no accounts, no analytics.
## Configure
- Local: `flutter run --dart-define=API_KEY=your_key`
- GitHub Actions: add repository secret `API_KEY`.
- Provider/URLs/refresh rates: `lib/config.dart`.
- News (RSS) and Highlights (JSON endpoint) are OFF until you set `newsFeedUrl` / `highlightsUrlTemplate` in `lib/config.dart`.
## Build
Push to GitHub; `.github/workflows/build.yml` generates the Android scaffold and builds the APK.
